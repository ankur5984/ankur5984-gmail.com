package com.app.dao;

import com.app.pojos.PaymentGateway;

public interface IPayamentGatewayDao {
	
	String paymentGateway(PaymentGateway p);

}
