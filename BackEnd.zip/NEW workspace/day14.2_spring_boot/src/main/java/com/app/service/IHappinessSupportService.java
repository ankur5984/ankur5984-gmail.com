package com.app.service;

import com.app.pojos.Hapiness_Support;

public interface IHappinessSupportService {
	
	public String registerVenue(Hapiness_Support hs);
	
	

}
