package com.app.dao;

import com.app.pojos.Hapiness_Support;
import com.app.service.HappinesSupportService;

public interface IHappinessSupportDao {
	
	String registerLocation(Hapiness_Support hs);
}
