package com.app.dao;

import com.app.pojos.MoneySupport;

public interface IMoneySupportDao {

	
		public String addMoney(MoneySupport m);
}
