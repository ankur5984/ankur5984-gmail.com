package com.app.service;

import com.app.pojos.MoneySupport;
import com.app.pojos.User1;

public interface IMoneyService {

	String moneyService(MoneySupport m);
}
