package com.app.dao;

import java.util.List;

import com.app.pojos.*;
public interface IChildInfoDao {
	
	List<Childinfo> getChildInfo();

}
