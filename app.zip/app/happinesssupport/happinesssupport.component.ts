import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HappinessService } from '../service/happiness.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-happinesssupport',
  templateUrl: './happinesssupport.component.html',
  styleUrls: ['./happinesssupport.component.css']
})
export class HappinesssupportComponent implements OnInit {

  constructor(private http: HttpClient,
              private svc: HappinessService,
              public router: Router

  ) { }

  emp: any;
  msg: any;
  add(formdata) {
    console.log(formdata.form.value);
    this.emp = formdata.form.value;
    console.log(this.emp);
    this.svc.AddData(this.emp).subscribe((res) => {
      console.log(res);
      this.msg = 'Record added successfully' ;
      alert(this.msg);

     this.router.navigate(['home']);
    });

  }



  ngOnInit() {
  }




}

