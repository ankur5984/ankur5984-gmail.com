import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HappinesssupportComponent } from './happinesssupport.component';

describe('HappinesssupportComponent', () => {
  let component: HappinesssupportComponent;
  let fixture: ComponentFixture<HappinesssupportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HappinesssupportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HappinesssupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
