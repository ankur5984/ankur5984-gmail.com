import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { NeccessitysupportService } from '../service/neccessitysupport.service';
@Component({
  selector: 'app-neccessitysupport',
  templateUrl: './neccessitysupport.component.html',
  styleUrls: ['./neccessitysupport.component.css']
})
export class NeccessitysupportComponent implements OnInit {

  necessity: any;
  ness: any;
  msg: any;

  constructor(public neccessitysvc: NeccessitysupportService ,
    public router : Router ) { }

    add(formdata) {
      console.log(formdata.form.value);
      this.necessity= formdata.form.value;
      this.ness = {
        name: formdata.form.value.name,
        quantity: formdata.form.value.quantity,
        userId: sessionStorage.getItem('id')
      }

      console.log(this.ness);
      this.neccessitysvc.AddData(this.ness).subscribe((res) => {
        console.log(res);

        alert('successful');
        this.router.navigate(['home']);
      })

    }

  ngOnInit() {
  }
}
