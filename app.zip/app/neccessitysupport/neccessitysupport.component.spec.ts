import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NeccessitysupportComponent } from './neccessitysupport.component';

describe('NeccessitysupportComponent', () => {
  let component: NeccessitysupportComponent;
  let fixture: ComponentFixture<NeccessitysupportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NeccessitysupportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NeccessitysupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
