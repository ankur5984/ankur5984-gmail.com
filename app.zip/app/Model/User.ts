export class User
{
    constructor(private name:String,private age:number,private gender:string,private dob:Date,private address:string,private occupation:string,private regisration_date:Date,private mobile:string,private email:string,private password:String)
    {

    }


    // Integer userId;
	// String name;
	// String age;
	// String gender;
	// @JsonFormat(pattern = "yyyy-MM-dd")
	// Date dob;
	// String address;
	// String occupation;
	// @JsonFormat(pattern = "yyyy-MM-dd")
	// Date regisration_date;
	// String mobile;
	// String email;
	// String password;
}