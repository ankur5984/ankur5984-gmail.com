export class children
{
    constructor(private C_id:number, private  Name:String, private  Age:number, private Gender: String,private dob:Date,	private  N_id:number)
    {

    }

}