import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgetpasswoComponent } from './forgetpasswo.component';

describe('ForgetpasswoComponent', () => {
  let component: ForgetpasswoComponent;
  let fixture: ComponentFixture<ForgetpasswoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgetpasswoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgetpasswoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
