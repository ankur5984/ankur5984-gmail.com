import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-forgetpasswo',
  templateUrl: './forgetpasswo.component.html',
  styleUrls: ['./forgetpasswo.component.css']
})
export class ForgetpasswoComponent implements OnInit {
email:string;
user:string;
status=false;
sent=false;
  constructor(private svc:AuthenticationService) { }

  ngOnInit() {
  }
onSubmit()
{
  console.log(this.email);
 

 this. svc.forGet(this.email).subscribe(data=>{
    this.sent=true;
  console.log(data+"hello");
 },error=>
 {
  this.status=true;
  console.log(error);
 })
}

}
