import { Component, OnInit } from '@angular/core';
import { Currentneed1Service } from '../service/currentneed1.service';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-currentneed',
  templateUrl: './currentneed.component.html',
  styleUrls: ['./currentneed.component.css']
})
export class CurrentneedComponent implements OnInit {


  currentneed: any = [];
  constructor(public dataService: Currentneed1Service, public router: RouterModule) {}




  ngOnInit() {
    this.getList();
  }

  getList() {
    this.dataService.getList().then(response => {

      console.log(response);
      this.currentneed = response;
    }).catch(error => {
        console.log(error);
      });

  }

}
