import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentneedComponent } from './currentneed.component';

describe('CurrentneedComponent', () => {
  let component: CurrentneedComponent;
  let fixture: ComponentFixture<CurrentneedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentneedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentneedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
