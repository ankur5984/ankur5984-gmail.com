import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../Model/User';
import { AuthenticationService } from '../service/authentication.service';
import { ActivatedRoute, Router } from '@angular/router';
import { PayementService } from '../service/payement.service';
import { LocationStrategy } from '@angular/common';


@Component({
  selector: 'app-payementdetails',
  templateUrl: './payementdetails.component.html',
  styleUrls: ['./payementdetails.component.css']
})
export class PayementdetailsComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;

  public id: string;
  payement:any;


  constructor(private svc:PayementService,private formBuilder: FormBuilder,private route: ActivatedRoute,
    private router: Router,private auth: AuthenticationService) {



  }

  ngOnInit() {


4
5



    this.registerForm = this.formBuilder.group({
      desc:['',[Validators.required]],
       amount:['',[Validators.required]]

  })

  this.id = this.route.snapshot.paramMap.get('id');
  console.log(this.id);

  }

  get f() { return this.registerForm.controls; }

  onSubmit()
  {
    this.submitted = true;


          if (this.registerForm.invalid) {
              return;
          }

          console.log(this.registerForm.value.amount+this.registerForm.value.desc);

         console.log(this.registerForm.value);
    this.payement={
amount:this.registerForm.value.amount,
description:this.registerForm.value.desc,
userId:sessionStorage.getItem('id'),
'childInfo':{
  childId:this.id
}

         }

   this.svc.payement(this.payement).subscribe(data=>
    {
      if(data)
      {

        this.router.navigate(["/payment1",this.registerForm.value.amount]);
        this.auth.Logout();
      }
      else
      {
        alert("Something Went Wrong")
      }
    }


    );



        }




      }
