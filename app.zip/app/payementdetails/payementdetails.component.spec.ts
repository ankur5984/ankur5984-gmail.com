import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayementdetailsComponent } from './payementdetails.component';

describe('PayementdetailsComponent', () => {
  let component: PayementdetailsComponent;
  let fixture: ComponentFixture<PayementdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayementdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayementdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
