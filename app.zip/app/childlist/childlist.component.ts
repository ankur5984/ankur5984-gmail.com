import { Component, OnInit } from '@angular/core';
import { ChildService } from '../service/child.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-childlist',
  templateUrl: './childlist.component.html',
  styleUrls: ['./childlist.component.css']
})
export class ChildlistComponent implements OnInit {
child:any
  constructor(private svc:ChildService,private route:Router) {
  console.log("hello");
    this.svc.childlist().subscribe(data=>
      {
        this.child=data;
        console.log(data);
      }
      
      )

   }

  ngOnInit() {
  }
  onClick(child)
  {
   
    console.log(child);
    let id=child.childId
    this.route.navigate(['/payment',id]);

  }
}
