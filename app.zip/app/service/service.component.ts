import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css']
})
export class ServiceComponent implements OnInit {

  constructor(private route:Router,private auth:AuthenticationService) { }

  ngOnInit() {
  }

  onClickchild()
  {
    if(this.auth.isLogin())
    {
    this.route.navigate(['child']);
    }
    else
    {
      alert('Please login');
      this.route.navigate(['login']);
    }
  }
  onClickDonate()
  {
    if(this.auth.isLogin())
    {
    this.route.navigate(['money']);
    }
    else
    {
      alert('Please login');
      this.route.navigate(['login']);
    }
  }
  onClickVol()
  {

    if(this.auth.isLogin())
    {
    this.route.navigate(['volunteer']);
    }
    else
    {
      alert('Please login');
      this.route.navigate(['login']);
    }
  }
  onClicknecc()
  {

    if(this.auth.isLogin())
    {
    this.route.navigate(['neccessity']);
    }
    else
    {
      alert('Please login');
      this.route.navigate(['login']);
    }
  }

  onClickHappy()
  {

    if(this.auth.isLogin())
    {

    this.route.navigate(['happiness']);
    }
    else
    {
      alert('Please login');
      this.route.navigate(['login']);
    }

  }

}
