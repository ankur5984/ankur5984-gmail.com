import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class VolunteerService {

  constructor( private http:HttpClient) { }


  signUp(volunteer)
  {
    console.log(volunteer);
    return this.http.post("http://localhost:8080/test/volunteer_signup",volunteer);
     
  }
}
