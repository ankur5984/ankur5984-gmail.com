import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PayementService } from '../service/payement.service';

@Component({
  selector: 'app-moneysupport',
  templateUrl: './moneysupport.component.html',
  styleUrls: ['./moneysupport.component.css']
})
export class MoneysupportComponent implements OnInit {


  money: any;
  msg: any;
  constructor(public router: Router, public service: PayementService) { }

  ngOnInit() {
  }

  add(formdata) {
    this.money = formdata.form.value;

    
    this.service.AddMoney(this.money).subscribe((res) => {
      console.log(res);
      this.msg = 'Record added successfully';

    }
    );
    alert('successful');
    this.router.navigate(['home']);
  }


}
